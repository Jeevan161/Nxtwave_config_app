from django.apps import AppConfig


class BetaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'beta'
