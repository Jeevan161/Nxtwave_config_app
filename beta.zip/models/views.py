from django.shortcuts import render

# Create your all_views here.
